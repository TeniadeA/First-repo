package model.room;

public enum RoomType {
    //Setting a fixed value in my enum
    SINGLE("1"),
     DOUBLE("2");

    public final String tag;
    //Creating the constructor
    RoomType(String tag) {

        this.tag = tag;
    }
    public static RoomType valueOfTag(String tag) {
        for (RoomType roomType : values()) {
            if (roomType.tag.equals(tag)) {
                return roomType;
            }
        }
        //Could return a null if no match but this returns an exception instead
        throw new IllegalArgumentException();
    }
    }

