package model.room;

import java.util.Objects;

public class Room implements IRoom {

    //Creating variables
    private String roomNumber;
    private Double price;
    private RoomType enumeration;

    //Creating the constructor
    public Room(String roomNumber, Double price, RoomType enumeration) {
        super();
        this.roomNumber = roomNumber;
        this.price = price;
        this.enumeration = enumeration;
    }

    //Creating methods
    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public Double getRoomPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public RoomType getRoomType() {
        return enumeration;
    }

    public void setEnumeration(RoomType enumeration) {
        this.enumeration = enumeration;
    }

    public boolean isFree() {
        return Objects.equals(price, 0.0);
    }

    //Overriding the class
    @Override
    public String toString() {

        return "Room Number: " + roomNumber + "  " + "Price:" + price + "  " + " Room Type: " + enumeration;
    }

}