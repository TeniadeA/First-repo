package model.reservation;

import model.customer.Customer;
import model.room.IRoom;
import java.util.Date;

public class Reservation {

    //Creating the variables
    private Customer customer;
    private IRoom room;
    private Date checkInDate;
    private Date checkOutDate;

    //Creating the constructor
    public Reservation(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {
        super();
        this.customer = customer;
        this.room = room;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }

    // Creating the methods
    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public IRoom getRoom() {
        return room;
    }

    public void setRoom(IRoom room) {
        this.room = room;
    }
    public Date getCheckIn() {
        return checkInDate;
    }

    public void setCheckIn(Date checkInDate) {
        this.checkInDate = checkInDate;
    }
    public Date getCheckOut() {
        return checkOutDate;
    }

    public void setCheckOut(Date checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    //Overriding the class
    @Override
    public String toString() {
        return "Customer:\n" + customer
                + "\nRoom:\n" + room
                + "\nCheckInInformation:\n" + checkInDate
                + "\nCheckOutInformation:\n" + checkOutDate;

    }
}
