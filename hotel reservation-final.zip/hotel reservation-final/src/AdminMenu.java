
import api.AdminResource;
import model.customer.Customer;
import model.room.IRoom;
import model.room.Room;
import model.room.RoomType;

import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;

public class AdminMenu {
    static int back;
    private static final AdminResource adminResource = AdminResource.getSingleton();
    public static void backMenu() {
        printAdmin();
        while (back != 5) {
            adminMenu();
            int choice = adminChoice();
            newAction(choice);
        }
    }
    private static void printAdmin() {
        System.out.println("*==============================*");
        System.out.println("|    FOR  USE  OF               |");
        System.out.println("|   ADMIN PURPOSES ONLY         |");
        System.out.println("*==============================*");
    }
    private static void adminMenu() {
        System.out.println("See all admin available options\n"
                + "1) See all Customers\n"
                + "2) See all rooms\n "
                + "3) See all reservations\n"
                + "4) Add a room\n"
                + "5) Back to Main Menu\n");
    }
    public static int adminChoice() {
        Scanner scan = new Scanner(System.in);
        int choice = -1;
        while (choice < 0 && choice <= 4) {
            try {
                System.out.println("Enter your number:");
                choice = Integer.parseInt(scan.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid selection. Please try again.");
            }
        }
         return choice;
    }
    private static void newAction(int choice) {
        switch (choice) {
            case 1:
                seeAllCustomers();
                break;
            case 2:
                seeAllRooms();
                break;
            case 3:
                displayAllReservations();
                break;
            case 4:
                addRoom();
                break;
            case 5:
                MainMenu.runMenu();
                break;
            default:
                System.out.println("This is an invalid selection. Please use 1,2 3, 4, or 5");
                break;
        }
    }
    private static void seeAllCustomers() {
        Collection<Customer> customers = adminResource.getAllCustomers();
        if (customers.isEmpty()) {
            System.out.println("No customers found.");
        } else {
            adminResource.getAllCustomers().forEach(System.out::println);
        }
    }
    private static void seeAllRooms() {
        Collection<IRoom> rooms = adminResource.getAllRooms();
        if (rooms.isEmpty()) {
            System.out.println("No rooms found.");
        } else {
            adminResource.getAllRooms().forEach(System.out::println);
        }
    }
    private static void displayAllReservations() {
        adminResource.displayAllReservations();
    }
    private static void addRoom() {
        final Scanner scanner = new Scanner(System.in);

        System.out.println("Enter room number:");
        final String roomNumber = scanner.nextLine();

        System.out.println("Enter price per night:");
        final double roomPrice = enterPrice(scanner);

        System.out.println("Enter room type: 1 for single bed, 2 for double bed:");
        final RoomType roomType = enterRoomType(scanner);

        final Room room = new Room(roomNumber, roomPrice, roomType);

        adminResource.addRoom(Collections.singletonList(room));
        System.out.println("Room added successfully!");

        System.out.println("Would like to add another room? Y/N");
        addMore();
    }

    //Additional methods needed for the addRoom method
    private static double enterPrice(final Scanner scanner) {
        try {
            return Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException exp) {
            System.out.println("Invalid room price! Please, enter a valid double number");
            return enterPrice(scanner);
        }
    }
    private static RoomType enterRoomType(final Scanner scanner) {
        try {
            return RoomType.valueOfTag(scanner.nextLine());
        } catch (IllegalArgumentException exp) {
            System.out.println("Wrong room type! Please, choose either 1 for single or 2 for double bed:");
            return enterRoomType(scanner);
        }
    }
    private static void addMore() {
        final Scanner scanner = new Scanner(System.in);
        try {
            String moreRoom;
            moreRoom = scanner.nextLine();
            if ("y".equals(moreRoom) || "Y".equals(moreRoom)) {
                addRoom();
            }
              else if ("n".equals(moreRoom) || "N".equals(moreRoom)) {
              //      adminMenu();
                }
        else  {
                System.out.println("Invalid input, Enter Y or N");
               addMore();
            }
     } catch (Exception e) {
            System.out.println("Invalid input, Enter Y or N");
        }
    }

}






