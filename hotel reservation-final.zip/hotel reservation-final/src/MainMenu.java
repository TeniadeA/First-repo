import api.HotelResource;
import model.reservation.Reservation;
import model.room.IRoom;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Scanner;

public class MainMenu {
    private static final String dateFormula = "MM/dd/yyyy";
    static int exit;


    //Creating static reference
    private static final HotelResource hotelResource = HotelResource.getSingleton();

    public static void runMenu() {
        printHeader();
        while (exit != 5) {
            mainMenuList();
            int choice = getChoice();
            performAction(choice);
        }
    }

    private static void printHeader() {
        System.out.println("*==============================*");
        System.out.println("|   WELCOME TO OUR             |");
        System.out.println("|   NEW HOTEL APPLICATION      |");
        System.out.println("*==============================*");
    }

    public static void mainMenuList() {
        System.out.println("\nWelcome to the Hotel Reservation Application\n" +
                "--------------------------------------------\n" +
                "1. Find and reserve a room\n" +
                "2. See my reservations\n" +
                "3. Create an Account\n" +
                "4. Admin\n" +
                "5. Exit\n" +
                "--------------------------------------------\n" +
                "Please select a number available on the menu option:\n");
    }

    public static int getChoice() {
        Scanner scan = new Scanner(System.in);
        int choice = -1;
        while (choice < 0 && choice <= 4) {
            try {
                System.out.println("Enter your number:");
                choice = Integer.parseInt(scan.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid selection. Please try again.");
            }
        }
        return choice;
    }

    private static void performAction(int choice) {
        switch (choice) {
            case 1:
                findAndReserveRoom();
                break;
            case 2:
                seeMyReservations();
                break;
            case 3:
                createAnAccount();
                break;
            case 4:
                AdminMenu.backMenu();
                break;
            case 5:
                exit = 5;
                System.out.println("Bye........exiting");
                break;
            default:
                System.out.println("This is an invalid selection. Please use 1,2 3, 4, or 5");
                break;
        }
    }


    //Declaring user input for date
    private static Date getUserInput(final Scanner scanner) {
        try {
            return new SimpleDateFormat(dateFormula).parse(scanner.nextLine());

        } catch (Exception ex) {
            System.out.println("Error: Invalid date format.");
            findAndReserveRoom();
        }
        return getUserInput(scanner);
    }


    public static void findAndReserveRoom() {
        final Scanner scanner = new Scanner(System.in);
        System.out.println("Enter your Check-In Date using the format mm/dd/yyyy");
        Date checkInDate = getUserInput(scanner);
        System.out.println("Enter your Check-out Date using the format mm/dd/yyyy");
        Date checkOutDate = getUserInput(scanner);
        if (checkOutDate.compareTo(checkInDate) < 0) {
            System.out.println(" please enter different dates as  check out date cannot" + " " +
                    "be before check in date\n");
            findAndReserveRoom();
        }
            /*if (checkInDate != null && checkOutDate != null) {
                availableAlternate();
            }  else {
                System.out.println("Please enter the required dates");
            }*/
        else {
            availableAlternate();
        }
    }





   /* private static void checkValidAndNull() {
        final Scanner scanner = new Scanner(System.in);
        Date checkInDate = getUserInput(scanner);
        Date checkOutDate = getUserInput(scanner);
        //if (checkInDate != null && checkOutDate != null) {
        Collection<IRoom> availableRooms = hotelResource.findARoom(checkInDate, checkOutDate);
        //  }


        if (checkOutDate.compareTo(checkInDate) < 0) {
            System.out.println(" please enter different dates as  check out date cannot" + " " +
                    "be before check in date\n");
            findAndReserveRoom();
        }

    }*/


    private static void reserveRoom(final Scanner scanner, final Date checkInDate, final Date checkOutDate, final Collection<IRoom> rooms) {
        System.out.println("Would you like to reserve a room? Y/N");
        booking(scanner);
        existingAccount(scanner);
        whichRoom(scanner, checkInDate, checkOutDate, rooms);
    }

    private static void booking(final Scanner scanner) {
        final String bookNow = scanner.nextLine();
        if ("y".equals(bookNow) || "Y".equals(bookNow)) {
            System.out.println("Do you have an account with us? Y/N");
        } else if ("n".equals(bookNow) || "N".equals(bookNow)) {
            createAnAccount();
        }
    }

    private static void existingAccount(final Scanner scanner) {
        final String haveAnAccount = scanner.nextLine();
        if ("y".equals(haveAnAccount) || "Y".equals(haveAnAccount)) {
            System.out.println("Enter Email address: name@domain.com");
            if ("n".equals(haveAnAccount) || "N".equals(haveAnAccount)) {
                System.out.println("Please, create an account.");
                createAnAccount();
                final String customerEmail = scanner.nextLine();
                if (hotelResource.getCustomer(customerEmail) != null) {
                    System.out.println("Please choose the room you would like to reserve?");
                } else {
                    System.out.println("Customer not found\n." + "Please create a new account.");
                    createAnAccount();
                }
            }

        }

    }

    private static void whichRoom(final Scanner scanner, final Date checkInDate, final Date checkOutDate,
                                  final Collection<IRoom> rooms) {
        final String roomNumber = scanner.nextLine();

        if (rooms.stream().anyMatch(room -> room.getRoomNumber().equals(roomNumber))) {
            final IRoom room = hotelResource.getRoom(roomNumber);
            final String customerEmail = scanner.nextLine();
            final Reservation reservation = hotelResource.bookARoom(customerEmail, room, checkInDate, checkOutDate);
            System.out.println("Reservation successful!\n" + reservation);
        } else {
            System.out.println("Error: The selected room number is not available.\nTry again.");
            whichRoom(scanner, checkInDate, checkOutDate, rooms);
        }
    }


    private static void availableAlternate() {
        final Scanner scanner = new Scanner(System.in);
        Date checkInDate = getUserInput(scanner);
        Date checkOutDate = getUserInput(scanner);
        Collection<IRoom> availableRooms = hotelResource.findARoom(checkInDate, checkOutDate);
        if (availableRooms.isEmpty()) {
            Collection<IRoom> alternateRooms = hotelResource.findAlternateRooms(checkInDate, checkOutDate);
            if (alternateRooms.isEmpty()) {
                System.out.println("There are no rooms available.");
            } else {

                roomInfo(alternateRooms);

            }
        } else {
            roomInfo(availableRooms);
            reserveRoom(scanner, checkInDate, checkOutDate, availableRooms);
        }
    }

    private static void roomInfo(final Collection<IRoom> rooms) {
        final Scanner scanner = new Scanner(System.in);
        Date checkInDate = getUserInput(scanner);
        Date checkOutDate = getUserInput(scanner);
        Collection<IRoom> alternateRooms = hotelResource.findAlternateRooms(checkInDate, checkOutDate);
        final Date alternateCheckIn = hotelResource.addNewDateRange(checkInDate);
        final Date alternateCheckOut = hotelResource.addNewDateRange(checkOutDate);
        System.out.println("Rooms available only on the following days:" +
                "\nCheck-In Date:" + alternateCheckIn +
                "\nCheck-Out Date:" + alternateCheckOut);
        if (rooms.isEmpty()) {
            System.out.println("No rooms found.");
        } else {
            rooms.forEach(System.out::println);

            reserveRoom(scanner, alternateCheckIn, alternateCheckOut, alternateRooms);

        }
    }

    private static void reservationInfo(final Collection<Reservation> reservations) {
        if (reservations == null || reservations.isEmpty()) {
            System.out.println("No reservations found.");
        } else {
            reservations.forEach(reservation -> System.out.println("\n" + reservation));
        }
    }

    private static void seeMyReservations() {
        final Scanner scanner = new Scanner(System.in);
        System.out.println("Enter your Email address format: name@domain.com");
        final String customerEmail = scanner.nextLine();
        reservationInfo(hotelResource.getCustomersReservations(customerEmail));
    }


    private static void createAnAccount() {
        final Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Email address format: name@domain.com");
        final String email = scanner.nextLine();
        System.out.println("First Name:");
        final String firstName = scanner.nextLine();
        System.out.println("Last Name:");
        final String lastName = scanner.nextLine();
        try {
            hotelResource.createACustomer(email, firstName, lastName);
            System.out.println("Account created successfully!");
        } catch (IllegalArgumentException ex) {
            System.out.println(ex.getLocalizedMessage());
            createAnAccount();
        }
    }
}





