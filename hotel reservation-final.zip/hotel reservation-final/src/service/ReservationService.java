package service;

import model.customer.Customer;
import model.reservation.Reservation;
import model.room.IRoom;

import java.util.*;
import java.util.stream.Collectors;

public class ReservationService {

    //Providing the Static reference
    private static final ReservationService SINGLETON = new ReservationService();
    private static final Map<String, IRoom> mapOfRooms = new HashMap<String, IRoom>();
    private final Map<String, Collection<Reservation>> reservations = new HashMap<>();
    private ReservationService() {
    }
    public static ReservationService getSingleton() {
        return SINGLETON;
    }

    //Setting the additional range of search when the customer input range is not available
    private static final int Date_Range_Search = 7;
    public void addRoom(IRoom room) {
        mapOfRooms.put(room.getRoomNumber(), room);
    }
    public IRoom getARoom(String roomId) {
        return mapOfRooms.get(roomId);
    }

    public Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {
        Reservation reservation = new Reservation(customer, room, checkInDate, checkOutDate);
        Collection<Reservation> customerReservation = getCustomersReservation(customer);
        if (customerReservation == null) {
            customerReservation = new LinkedList<>();
        }
        customerReservation.add(reservation);
        reservations.put(customer.getEmail(), customerReservation);
        return reservation;
    }
    public Collection<IRoom> getAllRooms() {
        return mapOfRooms.values();
    }
    public Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate) {
        return findAvailableRooms(checkInDate, checkOutDate);
    }
  public Collection<IRoom> findAlternativeRooms(final Date checkInDate, final Date checkOutDate) {
        return findAvailableRooms(addNewDateRange(checkInDate), addNewDateRange(checkOutDate));
    }
    private Collection<IRoom> findAvailableRooms(final Date checkInDate, final Date checkOutDate) {
         Collection<Reservation> allReservations = allReservations();
         Collection<IRoom> isNotAvailable = new LinkedList<>();
       for (Reservation reservation : allReservations) {
            if (conflictInReservation(reservation, checkInDate, checkOutDate)) {
                isNotAvailable.add(reservation.getRoom());
            }
        }

        return mapOfRooms.values().stream().filter(room -> isNotAvailable.stream()
                        .noneMatch(noRoom -> noRoom.equals(room)))
                .collect(Collectors.toList());
    }
    public Date addNewDateRange(final Date date) {
        Calendar c = Calendar.getInstance();
       c.add(Calendar.DATE, Date_Range_Search);
        return date;
    }
   private boolean conflictInReservation(final Reservation reservation, final Date checkInDate, final Date checkOutDate){
        return checkInDate.before(reservation.getCheckOut())
                && checkOutDate.after(reservation.getCheckIn());
    }
        public Collection<Reservation> getCustomersReservation ( final Customer customer){
            return reservations.get(customer.getEmail());
        }
        public void printAllReservation () {
            Collection<Reservation> reservations = allReservations();

            if (reservations.isEmpty()) {
                System.out.println("No reservations found.");
            } else {
                for (Reservation reservation : reservations) {
                    System.out.println(reservation + "\n");
                }
            }
        }
    private Collection<Reservation> allReservations () {
       Collection<Reservation> allReservations = new LinkedList<>();

        for (Collection<Reservation> reservations : reservations.values()) {
            allReservations.addAll(reservations);
        }
        return allReservations;
    }
}
