import api.HotelResource;
import model.customer.Customer;
import model.reservation.Reservation;
import model.room.IRoom;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Scanner;

public class MainMenu {
    private static final String dateFormula = "MM/dd/yyyy";
    static int exit;


    //Creating static reference
    private static final HotelResource hotelResource = HotelResource.getSingleton();

    public static void runMenu() {
        printHeader();
        while (exit != 5) {
            mainMenuList();
            int choice = getChoice();
            performAction(choice);
        }
    }

    private static void printHeader() {
        System.out.println("*==============================*");
        System.out.println("|   WELCOME TO OUR             |");
        System.out.println("|   NEW HOTEL APPLICATION      |");
        System.out.println("*==============================*");
    }

    public static void mainMenuList() {
        System.out.println("\nWelcome to the Hotel Reservation Application\n" +
                "--------------------------------------------\n" +
                "1. Find and reserve a room\n" +
                "2. See my reservations\n" +
                "3. Create an Account\n" +
                "4. Admin\n" +
                "5. Exit\n" +
                "--------------------------------------------\n" +
                "Please select a number available on the menu option:\n");
    }

    public static int getChoice() {
        Scanner scan = new Scanner(System.in);
        int choice = -1;
        while (choice < 0 && choice <= 4) {
            try {
                System.out.println("Enter your number:");
                choice = Integer.parseInt(scan.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid selection. Please try again.");
            }
        }
        return choice;
    }

    private static void performAction(int choice) {
        switch (choice) {
            case 1:
                findAndReserveRoom();
                break;
            case 2:
                seeMyReservations();
                break;
            case 3:
                createAnAccount();
                break;
            case 4:
                AdminMenu.backMenu();
                break;
            case 5:
                exit = 5;
                System.out.println("Bye........exiting");
                break;
            default:
                System.out.println("This is an invalid selection. Please use 1,2 3, 4, or 5");
                break;
        }
    }
    private static void reservationInfo(final Collection<Reservation> reservations) {
        if (reservations == null || reservations.isEmpty()) {
            System.out.println("No reservations found.");
        } else {
            reservations.forEach(reservation -> System.out.println("\n" + reservation));
        }
    }

    private static void seeMyReservations() {
        final Scanner scanner = new Scanner(System.in);
        System.out.println("Enter your Email address format: name@domain.com");
        final String customerEmail = scanner.nextLine();
        reservationInfo(hotelResource.getCustomersReservations(customerEmail));
    }


    private static void createAnAccount() {
        try {
        final Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Email address format: name@domain.com");
        final String email = scanner.nextLine();
        System.out.println("First Name:");
        final String firstName = scanner.nextLine();
        System.out.println("Last Name:");
        final String lastName = scanner.nextLine();
         hotelResource.createACustomer(email, firstName, lastName);
         System.out.println("Account created successfully!");
        } catch (Exception ex) {
            System.out.println("Try again");
            createAnAccount();
        }
    }

    private static void whichRoom(  String customerEmail, final Date checkInDate,
                                    final Date checkOutDate, final Collection<IRoom> rooms) {
      final Scanner scanner = new Scanner(System.in);
      System.out.println("Please choose the room you would like to reserve?");
      final String roomNumber = scanner.nextLine();
        //final Collection<IRoom> rooms = hotelResource.findARoom( checkInDate, checkOutDate);
        if (rooms.stream().anyMatch(room -> room.getRoomNumber().equals(roomNumber))) {
            final IRoom room = hotelResource.getRoom(roomNumber);
            Reservation reservation = hotelResource.bookARoom(customerEmail, room, checkInDate, checkOutDate);
            System.out.println("Reservation complete!\n" + reservation);
        } else {
            System.out.println("Error: The selected room number is not available.\nTry again.");
            whichRoom(customerEmail);
        }
    }
    private static void existingAccount() {
        final Scanner scanner = new Scanner(System.in);
        final String haveAnAccount = scanner.nextLine();
        if ("y".equals(haveAnAccount) || "Y".equals(haveAnAccount)) {
            System.out.println("Enter Email address: name@domain.com");
            final String customerEmail = scanner.nextLine();

            if (hotelResource.getCustomer(customerEmail) != null) {

               whichRoom(customerEmail);

            } else {
                System.out.println("Customer not found\n." + "Please create a new account.");
                createAnAccount();
            }
        }
        if ("n".equals(haveAnAccount) || "N".equals(haveAnAccount)) {
            System.out.println("Please, create an account.");
            createAnAccount();
            //final String customerEmail = scanner.nextLine();
        }
    }

    private static void booking() {
        final Scanner scanner = new Scanner(System.in);
        final String bookNow = scanner.nextLine();
        System.out.println("Do you have an existing account ? Y/N");
        if ("y".equals(bookNow) || "Y".equals(bookNow)) {
            existingAccount();
        } else if ("n".equals(bookNow) || "N".equals(bookNow)) {
            createAnAccount();
        }
    }

    private static void reserveRoom(  ) {
        final Scanner scanner = new Scanner(System.in);
        System.out.println("Would you like to reserve a room? Y/N");
        String reserveNow = scanner.nextLine();
        if ("y".equals(reserveNow) || "Y".equals(reserveNow)) {
            booking();
            existingAccount();

        } else {
            mainMenuList();
        }
    }

    private static void roomInfo(final Collection<IRoom> rooms) {
        if (rooms.isEmpty()) {
            System.out.println("No rooms found.");
        } else {
            rooms.forEach(room -> System.out.println("\n" + room));
        }
    }

    public static void availableAlternate(  Date checkInDate, Date checkOutDate) {
       if (checkOutDate.compareTo(checkInDate) < 0) {
            System.out.println("Ensure checkout is not a past date");
        } if (checkOutDate.compareTo(checkInDate) > 0) {
            Collection<IRoom> available = hotelResource.findARoom(checkInDate, checkOutDate);
            roomInfo(available);
            reserveRoom();

         if (available.isEmpty()) {
             Collection<IRoom> alternate = hotelResource.findAlternateRooms(checkInDate, checkOutDate);
             Date alternateCheckIn = hotelResource.addNewDateRange(checkInDate);
             Date alternateCheckOut = hotelResource.addNewDateRange(checkOutDate);
             System.out.println("Please see alternate dates:" + alternateCheckIn+ ""+ alternateCheckOut);
             roomInfo(alternate);
             reserveRoom();

             if (alternate.isEmpty()) {
                 System.out.println("There are no rooms available.");

             }
         }
        }
    }

    private static Date getUserInput(final Scanner scanner) {
        try {
            DateFormat df = new SimpleDateFormat(dateFormula);
            df.parse(scanner.nextLine());
        } catch (ParseException e) {
            System.out.println("Error: Invalid date format.");
            findAndReserveRoom();
        }
        return null;
    }

    public static void findAndReserveRoom() {
        final Scanner scanner = new Scanner(System.in);
        System.out.println("Enter your Check-In Date using the format mm/dd/yyyy");
        Date checkInDate = getUserInput(scanner);
        System.out.println("Enter your Check-out Date using the format mm/dd/yyyy");
        Date checkOutDate = getUserInput(scanner);
       if (checkInDate != null && checkOutDate != null) {
            availableAlternate( checkInDate, checkOutDate);
        } else {
            System.out.println(" please enter an input in the format MM/dd/yyyy");
            findAndReserveRoom();
        }

    }
}








