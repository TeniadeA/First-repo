package api;

import model.customer.Customer;
import model.reservation.Reservation;
import model.room.IRoom;
import service.CustomerService;
import service.ReservationService;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;

public class HotelResource {
    //Creating the Static reference
    private static final HotelResource SINGLETON = new HotelResource();
    private final CustomerService customerServe = CustomerService.getSingleton();
    private final ReservationService reservationServe = ReservationService.getSingleton();

    private HotelResource() {
    }

    public static HotelResource getSingleton() {
        return SINGLETON;
    }

    //creating the methods already provided in the project
    public Customer getCustomer(String email) {
        return customerServe.getCustomer(email);
    }

    public void createACustomer(String email, String firstName, String lastName) {
        customerServe.addCustomer(email, firstName, lastName);
    }

    public IRoom getRoom(String roomNumber) {
        return reservationServe.getARoom(roomNumber);
    }

    public Reservation bookARoom(String customerEmail, IRoom room, Date checkInDate, Date checkOutDate) {
        return reservationServe.reserveARoom(getCustomer(customerEmail), room, checkInDate, checkOutDate);
    }

    //This is needed to find the alternative dates
    public Date addNewDateRange(final Date date) {
        return reservationServe.addNewDateRange(date);
    }

    public Collection<Reservation> getCustomersReservations(String customerEmail) {
        final Customer customer = getCustomer(customerEmail);
        if (customer == null) {
            return Collections.emptyList();
        }
        return reservationServe.getCustomersReservation(getCustomer(customerEmail));
    }

    public Collection<IRoom> findARoom(Date checkInDate, Date checkOutDate) {
        return reservationServe.findRooms(checkInDate, checkOutDate);
    }
/*Not part of given methods but was introduced because it is needed for the alternative rooms
   if a  customer date search is not available*/

    public Collection<IRoom> findAlternateRooms(final Date checkIn, final Date checkOut) {
        return reservationServe.findAlternativeRooms(checkIn, checkOut);
    }
//new
    public Collection<IRoom> findAvailableRooms(Date checkInDate, Date checkOutDate) {
        return reservationServe.findAvailableRooms(checkInDate, checkOutDate);
    }
}

