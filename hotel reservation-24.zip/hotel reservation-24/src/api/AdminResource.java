package api;

import model.customer.Customer;
import model.room.IRoom;
import service.CustomerService;
import service.ReservationService;
import java.util.Collection;
import java.util.List;
public class AdminResource {
    //Creating a static reference
    private static final AdminResource SINGLETON = new AdminResource();
    private final CustomerService customerServe = CustomerService.getSingleton();
    private final ReservationService reservationServe = ReservationService.getSingleton();
    private AdminResource() {}

    public static AdminResource getSingleton() {
        return SINGLETON;
    }

// All methods as provided on the project page
    public Customer getCustomer (String email){
            return customerServe.getCustomer(email);
      }
        public void addRoom(List<IRoom> rooms){
           rooms.forEach(reservationServe::addRoom);
      }
        public Collection<IRoom> getAllRooms() {
            return reservationServe.getAllRooms();
        }
        public Collection<Customer>getAllCustomers() {
            return customerServe.getAllCustomers();
        }
        public void displayAllReservations(){
        reservationServe.printAllReservation();
        }

    }

