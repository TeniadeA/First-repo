package service;

import model.customer.Customer;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class CustomerService {

    //Providing the Static reference
    private static final CustomerService SINGLETON = new CustomerService();
    private static final Map<String, Customer> mapOfCustomers = new HashMap<String, Customer>();
    private CustomerService() {
    }
    public static CustomerService getSingleton() {
        return SINGLETON;
    }

    //Creating the methods as provided on the project
    public void addCustomer(String email, String firstName, String lastName){
        mapOfCustomers.put(email,new Customer(firstName,lastName,email));
    }
    public Customer getCustomer(String customerEmail){return mapOfCustomers.get(customerEmail);}
    public Collection<Customer> getAllCustomers(){
        return mapOfCustomers.values();
    }

}