package service;

import model.customer.Customer;
import model.reservation.Reservation;
import model.room.IRoom;
import model.room.Room;

import java.util.*;
import java.util.stream.Collectors;

public class ReservationService {

    //Providing the Static reference and initialization
    private static final ReservationService instance = new ReservationService();

    //creating a private constructor
    private ReservationService() {
    }

    public static ReservationService getInstance() {
        return instance;
    }

    private static final Map<String, IRoom> mapOfRooms = new HashMap<String, IRoom>();

    private final Collection<Reservation> reservations = new ArrayList<>();

    //Setting the additional range of search when the customer input range is not available
    private static final int Date_Range_Search = 7;

    public void addRoom(IRoom room) {
        //Ensuring that duplicate rooms are not created
        if (!duplicateRooms(room.getRoomNumber())) {
            mapOfRooms.put(room.getRoomNumber(), room);
        }
    }

    public boolean duplicateRooms(String roomNumber) {
               return false;
    }

    public IRoom getARoom(String roomId) {
        return mapOfRooms.get(roomId);
    }
//preventing conflicts in reservation
    public Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {
        Reservation reservation = null;
        if (noConflictingReservation(room, checkInDate, checkOutDate)) {
            reservation = new Reservation(customer, room, checkInDate, checkOutDate);
            Collection<Reservation> customerReservation = getCustomersReservation(customer);
            if (customerReservation == null) {
                customerReservation = new LinkedList<>();

            }
            customerReservation.add(reservation);
            }
        return reservation;
    }
    public boolean noConflictingReservation(IRoom room, Date checkInDate, Date checkOutDate) {
        Collection<Reservation> existingReservation = getReservedRoom(room.getRoomNumber());
        boolean goodConflictIndicator = true;
        if (conflictingReservation(existingReservation, checkInDate, checkOutDate)) {
            goodConflictIndicator = false;
        }
        return goodConflictIndicator;
    }
    private Collection<Reservation> getReservedRoom(String roomNumber) {
        Collection<Reservation> existingReservation = new ArrayList<>();
        for (Reservation reservation : reservations){
            if (sameRoom(reservation, roomNumber)) {
                existingReservation.add(reservation);
            }
        }
        return existingReservation;
    }
    private boolean sameRoom(Reservation reservation, String roomNumber) {
        boolean sameNumber = false;
        if (reservation.getRoom().getRoomNumber().equalsIgnoreCase(roomNumber)) {
            sameNumber = true;
        }
        return sameNumber;
    }
    private boolean conflictingReservation(Collection<Reservation> existingReservation, Date checkInDate, Date checkOutDate) {
        boolean badConflictIndicator = false;
        for (Reservation reservation : existingReservation) {
            if (conflictExist(reservation, checkInDate, checkOutDate)) {
                badConflictIndicator = true;
            }
        }
        return badConflictIndicator;
    }
    boolean conflictExist(Reservation reservation, Date checkInDate, Date checkOutDate) {
        boolean conflictOccur = false;
        if (reservation.getCheckIn().before(checkOutDate) && reservation.getCheckOut().after(checkInDate)) {
            conflictOccur = true;
        } else if (reservation.getCheckIn().compareTo(checkInDate) == 0 &&
                reservation.getCheckOut().compareTo(checkOutDate) == 0) {
            conflictOccur = true;
        }
        return conflictOccur;
    }
    public Collection<IRoom> getAllRooms() {
        return mapOfRooms.values();
    }

    public Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate) {
        return findAvailableRooms(checkInDate, checkOutDate);
    }

    public Collection<IRoom> findAlternativeRooms(final Date checkInDate, final Date checkOutDate) {
        return findAvailableRooms(addNewDateRange(checkInDate), addNewDateRange(checkOutDate));
    }

    public Collection<IRoom> findAvailableRooms(final Date checkInDate, final Date checkOutDate) {
        Collection<Reservation> allReservations = allReservations();
        Collection<IRoom> isNotAvailable = new LinkedList<>();
        for (Reservation reservation : allReservations) {
            if (conflictExist(reservation, checkInDate, checkOutDate)) {
                isNotAvailable.add(reservation.getRoom());
            }
        }
        return mapOfRooms.values().stream()
                .filter(room -> isNotAvailable.stream()
                        .noneMatch(noRoom -> noRoom.equals(room)))
                .collect(Collectors.toList());
    }

    public Date addNewDateRange(final Date date) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE,Date_Range_Search);
        return date;
    }
    public Collection<Reservation> getCustomersReservation(final Customer customer) {
           return reservations;
    }

    public void printAllReservation() {
        Collection<Reservation> reservations = allReservations();
        if (reservations.isEmpty()) {
            System.out.println("No reservations found.");
        } else {
            for (Reservation reservation : reservations) {
                System.out.println(reservation + "\n");
            }
        }
    }

    private Collection<Reservation> allReservations() {
        Collection<Reservation> allReservations = new LinkedList<>();

        for (Reservation reservation : reservations) {
            allReservations.addAll(reservations);
        }
        return allReservations;

    }
}
