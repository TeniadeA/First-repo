package model.customer;

import java.util.Objects;
import java.util.regex.Pattern;

public class Customer {

    //Creating the variables
    private String firstName;
    private String lastName;
    private String email;

    //Setting the email Regex with a wildcard to stabilise input format
    private final String emailRegex = "(?)^(.+)@(.+).com$" ;
    private final Pattern pattern = Pattern.compile(emailRegex);
    public Customer(String firstName, String lastName, String email) {
        super();
        if(!pattern.matcher(email).matches()){
            throw new IllegalArgumentException("Please use acceptable email format\n"+
                    "Email should be in lower case");
        }
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }
    // Creating accessor and mutator methods
    public String getFirstName () {
        return firstName;
    }

    public void setFirstName (String firstName){
        this.firstName = firstName;
    }

    public String getLastName () {
        return lastName;
    }

    public void setLastName (String lastName){
        this.lastName = lastName;
      }

    public String getEmail () {
        return email;
    }

    public void setEmail (String email){
        this.email = email;
    }

    //Overriding the class
    @Override
    public String toString() {
        return "Customer{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                '}';
    }

    //This was generated from IntelliJ
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Customer customer)) return false;
        return getFirstName().equals(customer.getFirstName()) && getLastName().equals(customer.getLastName()) && getEmail().equals(customer.getEmail());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getFirstName(), getLastName(), getEmail());
    }
}

