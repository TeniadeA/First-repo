import api.HotelResource;
import model.reservation.Reservation;
import model.room.IRoom;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Scanner;

public class MainMenu {
    private static final String dateFormula = "MM/dd/yyyy";
    static int exit;
    private static final HotelResource hotelResource = HotelResource.getInstance();

    public static void runMenu() {
        printHeader();
        while (exit != 5) {
            mainMenuList();
            int choice = getChoice();
            performAction(choice);
        }
    }

    private static void printHeader() {
        System.out.println("*==============================*");
        System.out.println("|   WELCOME TO OUR             |");
        System.out.println("|   NEW HOTEL APPLICATION      |");
        System.out.println("*==============================*");
    }

    public static void mainMenuList() {
        System.out.println("\nWelcome to the Hotel Reservation Application\n" +
                "--------------------------------------------\n" +
                "1. Find and reserve a room\n" +
                "2. See my reservations\n" +
                "3. Create an Account\n" +
                "4. Admin\n" +
                "5. Exit\n" +
                "--------------------------------------------\n" +
                "Please select a number available on the menu option:\n");
    }

    public static int getChoice() {
        Scanner scan = new Scanner(System.in);
        int choice = -1;
        while (choice < 0 && choice <= 4) {
            try {
                System.out.println("Enter your number:");
                choice = Integer.parseInt(scan.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid selection. Please try again.");
            }
        }
        return choice;
    }

    private static void performAction(int choice) {
        switch (choice) {
            case 1 -> findAndReserveRoom();
            case 2 -> seeMyReservations();
            case 3 -> createAnAccount();
            case 4 -> AdminMenu.backMenu();
            case 5 -> {
                exit = 5;
                System.out.println("Bye........exiting");
            }
            default -> System.out.println("This is an invalid selection. Please use 1,2 3, 4, or 5");
        }
    }

    private static void reservationInfo(final Collection<Reservation> reservations) {
        if (reservations.isEmpty()) {
            System.out.println("There is no reservation.");
        } else {
            reservations.forEach(reservation -> System.out.println("\n" + reservation));
        }
    }

    private static void seeMyReservations() {
        final Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the Email address used for registration");
        final String customerEmail = scanner.nextLine();
        reservationInfo(hotelResource.getCustomersReservations(customerEmail));
    }

    private static void createAnAccount() {
        try {
            final Scanner scanner = new Scanner(System.in);
            System.out.println("Enter Email address");
            final String email = scanner.nextLine();
            System.out.println("First Name:");
            final String firstName = scanner.nextLine();
            System.out.println("Last Name:");
            final String lastName = scanner.nextLine();
            hotelResource.createACustomer(email, firstName, lastName);
            System.out.println("Account created successfully!");
        } catch (Exception ex) {
            System.out.println("Error: Invalid email format or email already exist");
            createAnAccount();
        }
    }

    private static void whichRoom(String customerEmail, Collection<IRoom> rooms, Date checkInDate, Date checkOutDate) {
        final Scanner scanner = new Scanner(System.in);
        System.out.println("Please choose the room you would like to reserve?");
        final String roomNumber = scanner.nextLine();
        if (rooms.stream().anyMatch(room -> room.getRoomNumber().equals(roomNumber))) {
            final IRoom room = hotelResource.getRoom(roomNumber);
            Reservation reservation = hotelResource.bookARoom(customerEmail, room, checkInDate, checkOutDate);
            System.out.println("Reservation complete!\n" + reservation);
        } else {
            System.out.println("Error: The selected room number is not available.\n Please try again.");
            mainMenuList();
        }
    }

    private static void existingAccount(Collection<IRoom> rooms, Date checkInDate, Date checkOutDate) {
        final Scanner scanner = new Scanner(System.in);
        System.out.println("Enter registered Email address");
        final String customerEmail = scanner.nextLine();

        if (hotelResource.getCustomer(customerEmail) != null) {
            whichRoom(customerEmail, rooms, checkInDate, checkOutDate);
        }

        if (hotelResource.getCustomer(customerEmail) == null) {
            System.out.println("Please, create an account.");
            createAnAccount();
        }
    }


    private static void booking(String reserveNow, Collection<IRoom> rooms, Date checkInDate, Date checkOutDate) {
        final Scanner scanner = new Scanner(System.in);
        System.out.println("Do you have an existing account ? Y/N");
        final String existingA = scanner.nextLine();
        if ("y".equals(existingA) || "Y".equals(existingA)) {
            existingAccount(rooms, checkInDate, checkOutDate);
        } else {
            createAnAccount();
        }
    }

    private static void reserveRoom(Collection<IRoom> rooms, Date checkInDate, Date checkOutDate) {
        final Scanner scanner = new Scanner(System.in);
        System.out.println("Would you like to reserve a room? Y/N");
        String reserveNow = scanner.nextLine();
        if ("y".equals(reserveNow) || "Y".equals(reserveNow)) {
            booking(reserveNow, rooms, checkInDate, checkOutDate);
        } else {
            mainMenuList();
        }
    }

    private static void roomInfo(final Collection<IRoom> rooms) {
        if (rooms.isEmpty()) {
            System.out.println("There are no rooms found.");
        } else {
            rooms.forEach(room -> System.out.println("\n" + room));
        }
    }

    public static void findAndReserveRoom() {
        Date checkInDate =null;
        try {
            final Scanner scanner = new Scanner(System.in);
            DateFormat df = new SimpleDateFormat(dateFormula);
            System.out.println("Enter your Check-In Date");
            String userInput = scanner.nextLine();
            checkInDate = df.parse(userInput);
        } catch (ParseException e) {
            System.out.println("Error: Invalid date format.");
            findAndReserveRoom();
        }
        Date checkOutDate = null;
        try {
            final Scanner scanner = new Scanner(System.in);
            DateFormat df = new SimpleDateFormat(dateFormula);
            System.out.println("Enter your Check-out Date");
            String userInputTwo = scanner.nextLine();
            checkOutDate = df.parse(userInputTwo);
        } catch (ParseException e) {
            System.out.println("Error: Invalid date format.");
            findAndReserveRoom();
        }
        Collection<IRoom> available = hotelResource.findARoom(checkInDate, checkOutDate);
        if (checkOutDate.compareTo(checkInDate) < 0) {
            System.out.println("Ensure checkout is not a past date");
            findAndReserveRoom();

        }
        if (!available.isEmpty()) {
            roomInfo(available);
            reserveRoom(available, checkInDate, checkOutDate);
        }
        else {
                Collection<IRoom> alternate = hotelResource.findAlternateRooms(checkInDate, checkOutDate);
                Date alternateCheckIn = hotelResource.addNewDateRange(checkInDate);
                Date alternateCheckOut = hotelResource.addNewDateRange(checkOutDate);
                System.out.println("Please see alternate dates:\n" + "" + "CheckIN:" + alternateCheckIn + "\n" + " " + "CheckOUT:" + alternateCheckOut);

                roomInfo(alternate);
                reserveRoom(alternate, alternateCheckIn, alternateCheckOut);

                if (alternate.isEmpty()) {
                    System.out.println("There are no rooms available. Please try different dates");

                }
            }
        }

    }



