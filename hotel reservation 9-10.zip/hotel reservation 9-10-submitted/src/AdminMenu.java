
import api.AdminResource;
import model.customer.Customer;
import model.room.IRoom;
import model.room.Room;
import model.room.RoomType;

import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;

public class AdminMenu {
    static int back;
    private static final AdminResource adminResource = AdminResource.getInstance();
    public static void backMenu() {
        printAdmin();
        while (back != 5) {
            adminMenu();
            int choice = adminChoice();
            newAction(choice);
        }
    }
    private static void printAdmin() {
        System.out.println("*==============================*");
        System.out.println("|    FOR  USE  OF               |");
        System.out.println("|   ADMIN PURPOSES ONLY         |");
        System.out.println("*==============================*");
    }
    private static void adminMenu() {
        System.out.println("See all admin available options\n"
                + "1) See all Customers\n"
                + "2) See all rooms\n "
                + "3) See all reservations\n"
                + "4) Add a room\n"
                + "5) Back to Main Menu\n");
    }
    public static int adminChoice() {
        Scanner scan = new Scanner(System.in);
        int choice = -1;
        while (choice < 0 && choice <= 4) {
            try {
                System.out.println("Enter your number:");
                choice = Integer.parseInt(scan.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid selection. Please try again.");
            }
        }
         return choice;
    }
    private static void newAction(int choice) {
        switch (choice) {
            case 1:
                seeAllCustomers();
                break;
            case 2:
                seeAllRooms();
                break;
            case 3:
                displayAllReservations();
                break;
            case 4:
                addRoom();
                break;
            case 5:
                MainMenu.runMenu();
                break;
            default:
                System.out.println("This is an invalid selection. Please use 1,2 3, 4, or 5");
                break;
        }
    }
    private static void seeAllCustomers() {
        Collection<Customer> customers = adminResource.getAllCustomers();
        if (customers.isEmpty()) {
            System.out.println("No customers found.");
        } else {
            adminResource.getAllCustomers().forEach(System.out::println);
        }
    }
    private static void seeAllRooms() {
        Collection<IRoom> rooms = adminResource.getAllRooms();
        if (rooms.isEmpty()) {
            System.out.println("No rooms found.");
        } else {
            adminResource.getAllRooms().forEach(System.out::println);
        }
    }
    private static void displayAllReservations() {
        adminResource.displayAllReservations();
    }

    private static void addRoom() {
        final Scanner scanner = new Scanner(System.in);

        System.out.println("Enter room number:");
        final String roomNumber = scanner.nextLine();

        System.out.println("Enter a double price value for the night:");
        final double price = checkPrice(scanner);

        System.out.println("Enter room type: 1 for single bed, 2 for double bed:");
        final RoomType roomType = theRoomType(scanner);

        final Room room = new Room(roomNumber, price, roomType);

        adminResource.addRoom(Collections.singletonList(room));
        System.out.println("Room added successfully!");

        System.out.println("Would like to add another room? Y/N");
        addMore();
    }

    private static void addMore() {
        final Scanner scanner = new Scanner(System.in);
         String moreRoom;
        moreRoom = scanner.nextLine();
        if ("y".equals(moreRoom) || "Y".equals(moreRoom)) {
            addRoom();
        } else if ("N".equals(moreRoom) || "n".equals(moreRoom)) {
           // adminMenu();
        } else {
            System.out.println("Invalid input, Enter Y or N");

        }
    }

    //Additional methods validating the  variables needed for the addRoom method
   /*private static String theRoomNumber(final Scanner scanner) {
       try {
           if (scanner.hasNext("[A-Za-z]*")) {
               return scanner.nextLine();
           } else {
               System.out.println("Error:Note room number should be in string");
               addRoom();
           }
        } catch (Exception e) {
           throw new RuntimeException(e);
       }
       return theRoomNumber(scanner);
   }*/

       private static double checkPrice(final Scanner scanner) {
        try {
            return Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException exp) {
            System.out.println("Error:Note price should be in decimal");
        }
        return checkPrice(scanner);
    }

    private static RoomType theRoomType(final Scanner scanner) {
        try {
            return RoomType.valueOfTag(scanner.nextLine());
        } catch (IllegalArgumentException exp) {
            System.out.println("Error: Note  1 is for single and 2 is for double bedrooms:");
            return theRoomType(scanner);
        }
    }



}






