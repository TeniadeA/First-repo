package api;

import model.customer.Customer;
import model.room.IRoom;
import service.CustomerService;
import service.ReservationService;
import java.util.Collection;
import java.util.List;
public class AdminResource {
    //Creating a static reference
    private static final AdminResource instance = new AdminResource();
    private AdminResource() {

    }
     public synchronized static AdminResource getInstance() {
             return instance;
    }
    private final CustomerService customerServe = CustomerService.getInstance();
    private final ReservationService reservationServe = ReservationService.getInstance();

// All methods as provided on the project page

     public Customer getCustomer (String email){
            return customerServe.getCustomer(email);
      }
        public void addRoom(List<IRoom> rooms){
           rooms.forEach(reservationServe::addRoom);
      }
        public Collection<IRoom> getAllRooms() {
            return reservationServe.getAllRooms();
        }
        public Collection<Customer>getAllCustomers() {
            return customerServe.getAllCustomers();
        }
        public void displayAllReservations(){
        reservationServe.printAllReservation();
        }

    }

