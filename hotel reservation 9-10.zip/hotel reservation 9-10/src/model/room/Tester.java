package model.room;

import model.customer.Customer;

public class Tester {
    public static void main(String[] args) {
        Customer customer = new Customer("Paul", "Milik", "pmm@yahoo.com");
        System.out.println(customer);
    }
}

//Runs only based on the three models-customer, reservation and room.