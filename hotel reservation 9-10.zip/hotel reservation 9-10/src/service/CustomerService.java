package service;

import model.customer.Customer;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class CustomerService {

    //Providing the Static reference and initialization
    private static final CustomerService instance = new CustomerService();

    //creating a private constructor
    private CustomerService() {
    }

    //Returning the pre-initialized static variable
    public static CustomerService getInstance() {
        return instance;
    }

    private final Map<String, Customer> mapOfCustomers = new HashMap<String, Customer>();

    public void addCustomer(String email, String firstName, String lastName)throws IllegalArgumentException{
        Customer customer = new Customer(firstName, lastName, email);
        //Ensuring unique customers are created using the email address.
        if(!anyExistingCustomer(email)) {
            mapOfCustomers.put(email, customer);
            }else{
                throw new IllegalArgumentException("This email:" + email + " is already on file");
            }
        }
    public boolean anyExistingCustomer(String email){
        boolean existAlready =false;
        Customer customer =  mapOfCustomers.get(email);
        if (customer != null)
            existAlready =true;
        return existAlready;
    }
    public Customer getCustomer(String customerEmail){
        return mapOfCustomers.get(customerEmail);}
    public Collection<Customer> getAllCustomers(){
        return mapOfCustomers.values();
    }

}